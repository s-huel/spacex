Joram:

Rubric	- -	-	+/-	+	++
Discipline & Work Ethic		+			
Helpfulness					++
Asks for feedback			++		
Gives feedback				++	
Concentration/focus         +
points: 25