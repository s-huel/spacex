Fabian:

Rubric	- -	-	+/-	+	++
Discipline & Work Ethic		+			
Helpfulness					+
Asks for feedback			+/-		
Gives feedback				++	
Concentration/focus         _
points: 25